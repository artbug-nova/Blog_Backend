package com.innotech.arangobee.changeset;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Класс, содержащий конкретные changeset-ы (@{@link ChangeSet})
 * @see ChangeSet
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface ChangeLog {
    /**
     * Последовательность, определяющая порядок классов changelog.
     * Если не задана, используется каноническое имя класса с сортировкой по алфавиту, по возрастанию.
     * @return порядок
     */
    String order() default "";
}
