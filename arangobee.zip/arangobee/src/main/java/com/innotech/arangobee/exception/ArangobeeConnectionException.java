package com.innotech.arangobee.exception;

/**
 * Ошибка при подключении к ArangoDB
 */
public class ArangobeeConnectionException extends ArangobeeException {
    public ArangobeeConnectionException(String message, Exception baseException) {
        super(message, baseException);
    }
}
