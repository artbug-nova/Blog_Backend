package com.innotech.arangobee.changeset;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Набор изменений для добавления в БД. Множество changeset-ов включены в один changelog.
 * @see ChangeLog
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ChangeSet {

    /**
     * Автор changeset-а.
     * Обязательный
     * @return автор
     */
    public String author();

    /**
     * Уникальный идентификатор changeset-а.
     * Обязательный
     * @return уникальный идентификатор
     */
    public String id();

    /**
     * Последовательность, определяющая правильный порядок changeset-ов. Сортируется по алфавиту, по возрастанию.
     * Обязательный.
     * @return порядок
     */
    public String order();

    /**
     * Выполняет changeset при каждом запуске arangobee, даже если он уже был выполнен ранее.
     * Необязательный (по умолчанию false)
     * @return выполнять ли всегда?
     */
    public boolean runAlways() default false;
}
