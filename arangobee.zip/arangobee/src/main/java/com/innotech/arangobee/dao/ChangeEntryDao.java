package com.innotech.arangobee.dao;

import java.util.Date;

import com.arangodb.model.CollectionCreateOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.arangodb.ArangoCollection;
import com.arangodb.ArangoDatabase;
import com.arangodb.entity.BaseDocument;
import com.innotech.arangobee.changeset.ChangeEntry;
import com.innotech.arangobee.exception.ArangobeeConnectionException;
import com.innotech.arangobee.exception.ArangobeeLockException;
import com.google.common.collect.ImmutableMap;

/**
 * DAO для работы с записями изменений
 */
public class ChangeEntryDao {
    private static final Logger logger=LoggerFactory.getLogger("Arangobee dao");

    private ArangoDatabase arangoDatabase;
    private ChangeEntryIndexDao indexDao;
    private String changelogCollectionName;
    private boolean waitForLock;
    private long changeLogLockWaitTime;
    private long changeLogLockPollRate;
    private boolean throwExceptionIfCannotObtainLock;

    private LockDao lockDao;

    public ChangeEntryDao(String changelogCollectionName, String lockCollectionName, boolean waitForLock, long changeLogLockWaitTime,
            long changeLogLockPollRate, boolean throwExceptionIfCannotObtainLock) {
        this.indexDao=new ChangeEntryIndexDao(changelogCollectionName);
        this.lockDao=new LockDao(lockCollectionName);
        this.changelogCollectionName=changelogCollectionName;
        this.waitForLock=waitForLock;
        this.changeLogLockWaitTime=changeLogLockWaitTime;
        this.changeLogLockPollRate=changeLogLockPollRate;
        this.throwExceptionIfCannotObtainLock=throwExceptionIfCannotObtainLock;
    }

    public ArangoDatabase getArangoDatabase() {
        return arangoDatabase;
    }

    public ArangoDatabase connectDb(ArangoDatabase arangoDatabase) {
        this.arangoDatabase=arangoDatabase;

        ensureChangeLogCollectionIndex(arangoDatabase, changelogCollectionName);
        initializeLock();
        return arangoDatabase;
    }

    /**
     * Попытка получить блокировку процесса
     *
     * @return ключ блокировки если успешно получена, null в противном случае
     * @throws ArangobeeConnectionException исключение
     * @throws ArangobeeLockException исключение
     */
    public String acquireProcessLock() throws ArangobeeConnectionException, ArangobeeLockException {
        verifyDbConnection();
        String acquired=lockDao.acquireLock(getArangoDatabase());

        if (acquired == null && waitForLock) {
            long timeToGiveUp=new Date().getTime() + (changeLogLockWaitTime * 1000 * 60);
            while (acquired == null && new Date().getTime() < timeToGiveUp) {
                acquired=lockDao.acquireLock(getArangoDatabase());
                if (acquired == null) {
                    logger.info("Ожидание блокировки changelog....");
                    try {
                        Thread.sleep(changeLogLockPollRate * 1000);
                    } catch (InterruptedException e) {
                        // ничего не делаем
                    }
                }
            }
        }

        if (acquired == null && throwExceptionIfCannotObtainLock) {
            logger.info("Arangobee не смог получить блокировку процесса. Выбрасывается исключение.");
            throw new ArangobeeLockException("Не удалось получить блокировку процесса");
        }

        return acquired;
    }

    public void releaseProcessLock(String lock) throws ArangobeeConnectionException {
        verifyDbConnection();
        lockDao.releaseLock(getArangoDatabase(), lock);
    }

    public boolean isProccessLockHeld() throws ArangobeeConnectionException {
        verifyDbConnection();
        return lockDao.isLockHeld(getArangoDatabase());
    }

    public boolean isNewChange(ChangeEntry changeEntry) throws ArangobeeConnectionException {
        verifyDbConnection();

        return !getArangoDatabase().query(
                "FOR t IN " + changelogCollectionName + " FILTER t." + ChangeEntry.KEY_CHANGEID + " == @" + ChangeEntry.KEY_CHANGEID + " && t."
                        + ChangeEntry.KEY_AUTHOR + " == @" + ChangeEntry.KEY_AUTHOR + " RETURN t", BaseDocument.class,
                ImmutableMap.<String, Object> of(ChangeEntry.KEY_CHANGEID, changeEntry.getChangeId(), ChangeEntry.KEY_AUTHOR, changeEntry.getAuthor()), null
                ).hasNext();
    }

    public void save(ChangeEntry changeEntry) throws ArangobeeConnectionException {
        verifyDbConnection();

        ArangoCollection arangobeeLog=getArangoDatabase().collection(changelogCollectionName);
        arangobeeLog.insertDocument(changeEntry.buildFullDBObject());
    }

    private void verifyDbConnection() throws ArangobeeConnectionException {
        if (getArangoDatabase() == null) {
            throw new ArangobeeConnectionException("База данных не подключена. Arangobee выбросил непредвиденную ошибку", new NullPointerException());
        }
    }

    private void ensureChangeLogCollectionIndex(ArangoDatabase arangoDatabase, String collectionName) {

        ArangoCollection collection = arangoDatabase.collection(collectionName);
        if (!collection.exists()) {
            CollectionCreateOptions collectionCreateOptions = new CollectionCreateOptions();
            collectionCreateOptions.replicationFactor(2);
            arangoDatabase.createCollection(collectionName, collectionCreateOptions);
        }
        indexDao.createRequiredUniqueIndex(collection);
    }

    public void close() {
        // Ничего не делаем
    }

    private void initializeLock() {
        lockDao.intitializeLock(arangoDatabase);
    }

    public void setIndexDao(ChangeEntryIndexDao changeEntryIndexDao) {
        this.indexDao=changeEntryIndexDao;
    }

    /* Видимо для тестирования */
    void setLockDao(LockDao lockDao) {
        this.lockDao=lockDao;
    }

    public void setChangelogCollectionName(String changelogCollectionName) {
        this.changelogCollectionName=changelogCollectionName;
    }

    public void setLockCollectionName(String lockCollectionName) {
        this.lockDao.setLockCollectionName(lockCollectionName);
    }

    public boolean isWaitForLock() {
        return waitForLock;
    }

    public void setWaitForLock(boolean waitForLock) {
        this.waitForLock=waitForLock;
    }

    public long getChangeLogLockWaitTime() {
        return changeLogLockWaitTime;
    }

    public void setChangeLogLockWaitTime(long changeLogLockWaitTime) {
        this.changeLogLockWaitTime=changeLogLockWaitTime;
    }

    public long getChangeLogLockPollRate() {
        return changeLogLockPollRate;
    }

    public void setChangeLogLockPollRate(long changeLogLockPollRate) {
        this.changeLogLockPollRate=changeLogLockPollRate;
    }

    public boolean isThrowExceptionIfCannotObtainLock() {
        return throwExceptionIfCannotObtainLock;
    }

    public void setThrowExceptionIfCannotObtainLock(boolean throwExceptionIfCannotObtainLock) {
        this.throwExceptionIfCannotObtainLock=throwExceptionIfCannotObtainLock;
    }

}
