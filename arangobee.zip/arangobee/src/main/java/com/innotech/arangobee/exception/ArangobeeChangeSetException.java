package com.innotech.arangobee.exception;

/**
 * Исключение при ошибке в changeset
 */
public class ArangobeeChangeSetException extends ArangobeeException {
    public ArangobeeChangeSetException(String message) {
        super(message);
    }
}