package com.innotech.arangobee.exception;

/**
 * Исключение при ошибке конфигурации
 */
public class ArangobeeConfigurationException extends ArangobeeException {
    public ArangobeeConfigurationException(String message) {
        super(message);
    }
}
