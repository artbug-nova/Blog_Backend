package com.innotech.arangobee.dao;

import com.arangodb.ArangoCollection;
import com.arangodb.ArangoDatabase;
import com.arangodb.entity.BaseDocument;
import com.arangodb.model.PersistentIndexOptions;
import com.innotech.arangobee.changeset.ChangeEntry;
import com.google.common.collect.ImmutableList;

/**
 * DAO для работы с индексами записей изменений
 */
public class ChangeEntryIndexDao {
    public ChangeEntryIndexDao(String changelogCollectionName) {
    }

    public void createRequiredUniqueIndex(ArangoCollection collection) {
        collection.ensurePersistentIndex(ImmutableList.of(ChangeEntry.KEY_CHANGEID, ChangeEntry.KEY_AUTHOR), new PersistentIndexOptions().unique(true));
    }

    public boolean isUnique(BaseDocument index) {
        Object unique=index.getAttribute("unique");
        if (unique != null && unique instanceof Boolean) {
            return (Boolean) unique;
        } else {
            return false;
        }
    }

    public void dropIndex(ArangoDatabase db, BaseDocument index) {
        db.deleteIndex(index.getAttribute("name").toString());
    }

}
