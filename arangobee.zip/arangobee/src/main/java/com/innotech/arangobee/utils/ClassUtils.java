package com.innotech.arangobee.utils;

/**
 * Вспомогательные утилиты для работы с классами.
 */
public class ClassUtils {

    /**
     * Определяет, присутствует ли {@link Class} с указанным именем и может ли быть загружен.
     * Вернёт {@code false}, если класс или одна из его зависимостей отсутствует или не может быть загружена.
     * @param className имя класса для проверки
     * @param classLoader загрузчик классов для использования
     * (может быть {@code null}, что означает загрузчик классов по умолчанию)
     * @return присутствует ли указанный класс
     */
    public static boolean isPresent(String className, ClassLoader classLoader) {
        try {
            Class.forName(className);
            return true;
        } catch (Throwable ex) {
            // Класс или одна из его зависимостей отсутствует...
            return false;
        }
    }

}
