package com.innotech.arangobee;

import static org.springframework.util.StringUtils.hasText;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.env.Environment;

import com.arangodb.ArangoDatabase;
import com.arangodb.springframework.core.template.ArangoTemplate;
import com.innotech.arangobee.changeset.ChangeEntry;
import com.innotech.arangobee.dao.ChangeEntryDao;
import com.innotech.arangobee.exception.ArangobeeChangeSetException;
import com.innotech.arangobee.exception.ArangobeeConfigurationException;
import com.innotech.arangobee.exception.ArangobeeConnectionException;
import com.innotech.arangobee.exception.ArangobeeException;
import com.innotech.arangobee.utils.ChangeService;

/**
 * Основной класс для запуска миграций Arangobee
 */
public class Arangobee implements InitializingBean {
    private static final Logger logger=LoggerFactory.getLogger(Arangobee.class);

    private static final String DEFAULT_CHANGELOG_COLLECTION_NAME="dbchangelog";
    private static final String DEFAULT_LOCK_COLLECTION_NAME="arangolock";
    private static final boolean DEFAULT_WAIT_FOR_LOCK=false;
    private static final long DEFAULT_CHANGE_LOG_LOCK_WAIT_TIME=5L;
    private static final long DEFAULT_CHANGE_LOG_LOCK_POLL_RATE=10L;
    private static final boolean DEFAULT_THROW_EXCEPTION_IF_CANNOT_OBTAIN_LOCK=false;

    private ChangeEntryDao dao;

    private String changeLogsScanPackage;
    private Environment springEnvironment;

    private final ArangoDatabase arangoDatabase;

    private final AutowireCapableBeanFactory autowireCapableBeanFactory;

    private final int autowireMode;

    public Arangobee(ArangoDatabase arangoDatabase, AutowireCapableBeanFactory autowireCapableBeanFactory) {
        this(arangoDatabase, autowireCapableBeanFactory, AutowireCapableBeanFactory.AUTOWIRE_NO);
    }

    public Arangobee(ArangoDatabase arangoDatabase, AutowireCapableBeanFactory autowireCapableBeanFactory, int autowireMode) {
        this.arangoDatabase=arangoDatabase;
        this.autowireCapableBeanFactory=autowireCapableBeanFactory;
        this.autowireMode=autowireMode;
        this.dao=new ChangeEntryDao(DEFAULT_CHANGELOG_COLLECTION_NAME, DEFAULT_LOCK_COLLECTION_NAME, DEFAULT_WAIT_FOR_LOCK, DEFAULT_CHANGE_LOG_LOCK_WAIT_TIME,
                DEFAULT_CHANGE_LOG_LOCK_POLL_RATE, DEFAULT_THROW_EXCEPTION_IF_CANNOT_OBTAIN_LOCK);
    }

    public Arangobee dao(ChangeEntryDao dao) {
        this.dao=dao;
        return this;
    }

    /**
     * Для пользователей Spring: выполнение arangobee после создания бина в контексте Spring
     *
     * @throws Exception исключение
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        execute();
    }

    /**
     * Выполнение миграции
     *
     * @throws ArangobeeException исключение
     */
    public void execute() throws ArangobeeException {
        validateConfig();

        dao.connectDb(this.arangoDatabase);

        String lock=dao.acquireProcessLock();
        if (lock == null) {
            throw new ArangobeeException("Arangobee не смог получить блокировку процесса. Завершение.");
        }

        logger.info("Arangobee получил блокировку процесса, начинается последовательность миграции данных..");

        try {
            executeMigration();
        } finally {
            logger.info("Arangobee освобождает блокировку процесса.");
            dao.releaseProcessLock(lock);
        }

        logger.info("Arangobee завершил свою работу.");
    }

    private void executeMigration() throws ArangobeeConnectionException, ArangobeeException {

        ChangeService service=new ChangeService(changeLogsScanPackage, springEnvironment);

        for (Class<?> changelogClass : service.fetchChangeLogs()) {

            Object changelogInstance=null;
            try {
                changelogInstance=changelogClass.getConstructor().newInstance();
                if(autowireCapableBeanFactory!=null)
                    autowireCapableBeanFactory.autowireBeanProperties(changelogInstance, autowireMode, true);
                List<Method> changesetMethods=service.fetchChangeSets(changelogInstance.getClass());

                for (Method changesetMethod : changesetMethods) {
                    ChangeEntry changeEntry=service.createChangeEntry(changesetMethod);

                    try {
                        if (dao.isNewChange(changeEntry)) {
                            executeChangeSetMethod(changesetMethod, changelogInstance, dao.getArangoDatabase());
                            dao.save(changeEntry);
                            logger.info(changeEntry + " применён");
                        } else if (service.isRunAlwaysChangeSet(changesetMethod)) {
                            executeChangeSetMethod(changesetMethod, changelogInstance, dao.getArangoDatabase());
                            logger.info(changeEntry + " повторно применён");
                        } else {
                            logger.info(changeEntry + " пропущен");
                        }
                    } catch (ArangobeeChangeSetException e) {
                        logger.error(e.getMessage());
                    }
                }
            } catch (NoSuchMethodException e) {
                throw new ArangobeeException(e.getMessage(), e);
            } catch (IllegalAccessException e) {
                throw new ArangobeeException(e.getMessage(), e);
            } catch (InvocationTargetException e) {
                Throwable targetException=e.getTargetException();
                throw new ArangobeeException(targetException.getMessage(), e);
            } catch (InstantiationException e) {
                throw new ArangobeeException(e.getMessage(), e);
            }

        }
    }

    private Object executeChangeSetMethod(Method changeSetMethod, Object changeLogInstance, ArangoDatabase arangoDatabase)
            throws IllegalAccessException, InvocationTargetException, ArangobeeChangeSetException {
        if (changeSetMethod.getParameterTypes().length == 2 && changeSetMethod.getParameterTypes()[0].equals(ArangoTemplate.class)
                && changeSetMethod.getParameterTypes()[1].equals(Environment.class)) {
            logger.debug("метод с аргументами ArangoTemplate и environment");

            return changeSetMethod.invoke(changeLogInstance, arangoDatabase, springEnvironment);
        } else if (changeSetMethod.getParameterTypes().length == 1 && changeSetMethod.getParameterTypes()[0].equals(ArangoDatabase.class)) {
            logger.debug("метод с аргументом БД");

            return changeSetMethod.invoke(changeLogInstance, arangoDatabase);
        } else if (changeSetMethod.getParameterTypes().length == 0) {
            logger.debug("метод без параметров");

            return changeSetMethod.invoke(changeLogInstance);
        } else {
            throw new ArangobeeChangeSetException(
                    "Метод ChangeSet " + changeSetMethod.getName() + " имеет неправильный список аргументов. Смотрите документацию для подробностей!");
        }
    }

    private void validateConfig() throws ArangobeeConfigurationException {
        if (arangoDatabase == null) {
            throw new ArangobeeConfigurationException("База данных не установлена.");
        }
        if (!hasText(changeLogsScanPackage)) {
            throw new ArangobeeConfigurationException("Пакет для сканирования changelog-ов не установлен: используйте соответствующий сеттер");
        }
    }

    /**
     * @return true если выполнение в процессе, в любом процессе.
     * @throws ArangobeeConnectionException исключение
     */
    public boolean isExecutionInProgress() throws ArangobeeConnectionException {
        return dao.isProccessLockHeld();
    }

    /**
     * Имя пакета, в котором находятся классы с аннотацией @ChangeLog.
     *
     * @param changeLogsScanPackage пакет, в котором находятся ваши changelog-и
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setChangeLogsScanPackage(String changeLogsScanPackage) {
        this.changeLogsScanPackage=changeLogsScanPackage;
        return this;
    }

    /**
     * Функция включения/выключения ожидания блокировки, если она уже получена
     *
     * @param waitForLock Arangobee будет ожидать блокировку, если она уже получена, при значении true
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setWaitForLock(boolean waitForLock) {
        this.dao.setWaitForLock(waitForLock);
        return this;
    }

    /**
     * Время ожидания получения блокировки, если waitForLock равен true
     *
     * @param changeLogLockWaitTime время ожидания в минутах для получения блокировки
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setChangeLogLockWaitTime(long changeLogLockWaitTime) {
        this.dao.setChangeLogLockWaitTime(changeLogLockWaitTime);
        return this;
    }

    /**
     * Частота опроса для получения блокировки, если waitForLock равен true
     *
     * @param changeLogLockPollRate частота опроса в секундах для получения блокировки
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setChangeLogLockPollRate(long changeLogLockPollRate) {
        this.dao.setChangeLogLockPollRate(changeLogLockPollRate);
        return this;
    }

    /**
     * Функция включения/выключения выброса ArangobeeLockException, если Arangobee не может получить блокировку
     *
     * @param throwExceptionIfCannotObtainLock Arangobee выбросит ArangobeeLockException, если блокировку невозможно получить
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setThrowExceptionIfCannotObtainLock(boolean throwExceptionIfCannotObtainLock) {
        this.dao.setThrowExceptionIfCannotObtainLock(throwExceptionIfCannotObtainLock);
        return this;
    }

    /**
     * Установить объект Environment для интеграции с Spring Profiles (@Profile)
     *
     * @param environment объект org.springframework.core.env.Environment для внедрения
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setSpringEnvironment(Environment environment) {
        this.springEnvironment=environment;
        return this;
    }

    /**
     * Перезаписывает стандартное имя коллекции changelog, заданное в DEFAULT_CHANGELOG_COLLECTION_NAME.
     *
     * ВНИМАНИЕ! Используйте этот метод осторожно — при изменении имени в существующей системе
     * ваши changelog-и будут выполнены повторно на вашем экземпляре ArangoDB
     *
     * @param changelogCollectionName новое имя коллекции changelog
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setChangelogCollectionName(String changelogCollectionName) {
        this.dao.setChangelogCollectionName(changelogCollectionName);
        return this;
    }

    /**
     * Перезаписывает стандартное имя коллекции блокировок, заданное в DEFAULT_LOCK_COLLECTION_NAME
     *
     * @param lockCollectionName новое имя коллекции блокировок
     * @return объект Arangobee для цепочки вызовов
     */
    public Arangobee setLockCollectionName(String lockCollectionName) {
        this.dao.setLockCollectionName(lockCollectionName);
        return this;
    }

    /**
     * Закрывает экземпляр Arango, используемый Arangobee.
     * Закрывает соединение, с которым был инициализирован Arangobee, или то, которое было создано внутренне.
     */
    public void close() {
        dao.close();
    }
}
