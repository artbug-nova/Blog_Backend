package com.innotech.arangobee.exception;

/**
 * Ошибка при невозможности получить блокировку процесса
 */
public class ArangobeeLockException extends ArangobeeException {
    public ArangobeeLockException(String message) {
        super(message);
    }
}
