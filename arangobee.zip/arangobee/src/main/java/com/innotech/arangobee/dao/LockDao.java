package com.innotech.arangobee.dao;

import com.arangodb.ArangoCollection;
import com.arangodb.ArangoDBException;
import com.arangodb.ArangoDatabase;
import com.arangodb.entity.BaseDocument;
import com.arangodb.model.CollectionCreateOptions;


/**
 * DAO для работы с блокировками
 */
public class LockDao {
    private static final String LOCK_ENTRY_KEY_VAL="LOCK";
    private String lockCollectionName;

    public LockDao(String lockCollectionName) {
        this.lockCollectionName=lockCollectionName;
    }

    public void intitializeLock(ArangoDatabase arangoDatabase) {
        createCollectionAndUniqueIndexIfNotExists(arangoDatabase);
    }

    private void createCollectionAndUniqueIndexIfNotExists(ArangoDatabase arangoDatabase) {
        ArangoCollection collection = arangoDatabase.collection(lockCollectionName);
        if (!collection.exists()) {
            CollectionCreateOptions collectionCreateOptions = new CollectionCreateOptions();
            collectionCreateOptions.replicationFactor(2);
            arangoDatabase.createCollection(lockCollectionName, collectionCreateOptions);
        }
    }

    public String acquireLock(ArangoDatabase arangoDatabase) {

        BaseDocument insertObj=new BaseDocument();
        insertObj.setKey(LOCK_ENTRY_KEY_VAL);
        insertObj.addAttribute("status", "LOCK_HELD");

        // получение блокировки путём попытки вставить то же значение в коллекцию — если оно уже существует (т.е. блокировка удерживается),
        // будет выброшено исключение
        try {
            return arangoDatabase.collection(lockCollectionName).insertDocument(insertObj).getKey();
        } catch (ArangoDBException ex) {
            return null;
        }
    }

    public void releaseLock(ArangoDatabase arangoDatabase, String lock) {
        // освобождение блокировки путём удаления записи из коллекции
        arangoDatabase.collection(lockCollectionName).deleteDocument(lock);
    }

    /**
     * Проверяет, удерживается ли блокировка. Может использоваться, например, внешним процессом.
     *
     * @param arangoDatabase объект {@link ArangoDatabase}
     * @return true если блокировка в данный момент удерживается
     */
    public boolean isLockHeld(ArangoDatabase arangoDatabase) {
        return arangoDatabase.collection(lockCollectionName).count().getCount() == 1;
    }

    public void setLockCollectionName(String lockCollectionName) {
        this.lockCollectionName=lockCollectionName;
    }

}
